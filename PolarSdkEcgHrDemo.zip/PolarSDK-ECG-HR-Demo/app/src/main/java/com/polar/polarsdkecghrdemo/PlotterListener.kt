package com.polar.polarsdkecghrdemo

interface PlotterListener {
    fun update()
}